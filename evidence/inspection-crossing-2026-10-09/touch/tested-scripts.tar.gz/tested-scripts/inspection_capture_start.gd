extends SceneTree
# Disable software 3D before building the actual main scene. The unchanged
# native world/input continues between supported, frozen capture frames.
func _initialize() -> void:
	root.disable_3d = true
	_start.call_deferred()
func _start() -> void:
	root.add_child(load("res://main.tscn").instantiate())
	root.disable_3d = true
	print("INSPECTION_CAPTURE_MODE disable_3d=%s size=%s" % [root.disable_3d, root.get_visible_rect().size])
